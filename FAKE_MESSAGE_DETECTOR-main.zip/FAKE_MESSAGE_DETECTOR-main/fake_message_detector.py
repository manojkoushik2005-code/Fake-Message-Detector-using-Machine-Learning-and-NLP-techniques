import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

data = pd.read_csv("dataset.csv")

X = data["message"]
y = data["label"]

vectorizer = TfidfVectorizer()
X_transformed = vectorizer.fit_transform(X)


X_train, X_test, y_train, y_test = train_test_split(X_transformed, y, test_size=0.2, random_state=42)


model = MultinomialNB()
model.fit(X_train, y_train)


y_pred = model.predict(X_test)
print("✅ Model Accuracy:", accuracy_score(y_test, y_pred))


def detect_message(msg):
    msg_transformed = vectorizer.transform([msg])
    prediction = model.predict(msg_transformed)
    return prediction[0]

while True:
    user_input = input("\nEnter a message (or type 'exit' to quit): ")
    if user_input.lower() == "exit":
        break
    print("Prediction:", detect_message(user_input))
